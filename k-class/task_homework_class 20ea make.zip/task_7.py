# 화초 클래스

class Flower:
    def __init__(self, name, color, price):
        self.name = name
        self.color = color
        self.price = price
    def plant(self, planting):
        pass

class Vase:
    def __init__(self, size, vase_color):
        self.size = size
        self.vase_color = vase_color

